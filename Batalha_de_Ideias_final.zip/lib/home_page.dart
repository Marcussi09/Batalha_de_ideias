import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  CollectionReference<Map<String, dynamic>> get ideias =>
      FirebaseFirestore.instance.collection('ideias');

  Future<void> votar(String id) async {
    await ideias.doc(id).update({
      'votos': FieldValue.increment(1),
    });
  }

  Future<void> excluir(BuildContext context, String id) async {
    final confirmar = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Excluir ideia'),
        content: const Text('Tem certeza que deseja excluir esta ideia?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Excluir'),
          ),
        ],
      ),
    );

    if (confirmar == true) {
      await ideias.doc(id).delete();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Batalha de Ideias',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _abrirCadastro(context),
        icon: const Icon(Icons.add),
        label: const Text('Nova ideia'),
      ),
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: ideias.snapshots(),
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return const Center(
              child: Text('Erro ao carregar as ideias.'),
            );
          }

          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          final docs = snapshot.data?.docs ?? [];

          docs.sort((a, b) {
            final votosA = (a.data()['votos'] ?? 0) as num;
            final votosB = (b.data()['votos'] ?? 0) as num;
            return votosB.compareTo(votosA);
          });

          if (docs.isEmpty) {
            return const Center(
              child: Padding(
                padding: EdgeInsets.all(24),
                child: Text(
                  'Nenhuma ideia cadastrada ainda.\n\nClique em "Nova ideia" para começar.',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 17),
                ),
              ),
            );
          }

          final maiorVoto = (docs.first.data()['votos'] ?? 0) as num;

          return ListView(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 100),
            children: [
              _rankingCard(docs.first.data(), maiorVoto),
              const SizedBox(height: 16),
              ...docs.map(
                (doc) => _ideiaCard(context, doc),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _rankingCard(Map<String, dynamic> data, num votos) {
    return Card(
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Row(
          children: [
            const CircleAvatar(
              radius: 25,
              child: Icon(Icons.emoji_events),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'IDEIA MAIS VOTADA',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 13,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    data['titulo']?.toString() ?? 'Sem título',
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 18,
                    ),
                  ),
                  Text('$votos votos'),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _ideiaCard(
    BuildContext context,
    QueryDocumentSnapshot<Map<String, dynamic>> doc,
  ) {
    final data = doc.data();
    final titulo = data['titulo']?.toString() ?? '';
    final descricao = data['descricao']?.toString() ?? '';
    final autor = data['autor']?.toString() ?? '';
    final votos = data['votos'] ?? 0;

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              titulo,
              style: const TextStyle(
                fontSize: 19,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Text(descricao),
            const SizedBox(height: 10),
            Text(
              'Autor: $autor',
              style: const TextStyle(fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                const Icon(Icons.favorite, size: 20),
                const SizedBox(width: 6),
                Text('$votos votos'),
                const Spacer(),
                OutlinedButton.icon(
                  onPressed: () => votar(doc.id),
                  icon: const Icon(Icons.how_to_vote),
                  label: const Text('Votar'),
                ),
                const SizedBox(width: 8),
                IconButton(
                  tooltip: 'Excluir',
                  onPressed: () => excluir(context, doc.id),
                  icon: const Icon(Icons.delete_outline),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _abrirCadastro(BuildContext context) {
    showDialog(
      context: context,
      builder: (_) => const CadastroIdeiaDialog(),
    );
  }
}

class CadastroIdeiaDialog extends StatefulWidget {
  const CadastroIdeiaDialog({super.key});

  @override
  State<CadastroIdeiaDialog> createState() => _CadastroIdeiaDialogState();
}

class _CadastroIdeiaDialogState extends State<CadastroIdeiaDialog> {
  final _formKey = GlobalKey<FormState>();
  final _titulo = TextEditingController();
  final _descricao = TextEditingController();
  final _autor = TextEditingController();
  bool salvando = false;

  @override
  void dispose() {
    _titulo.dispose();
    _descricao.dispose();
    _autor.dispose();
    super.dispose();
  }

  Future<void> salvar() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => salvando = true);

    await FirebaseFirestore.instance.collection('ideias').add({
      'titulo': _titulo.text.trim(),
      'descricao': _descricao.text.trim(),
      'autor': _autor.text.trim(),
      'votos': 0,
    });

    if (mounted) {
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Cadastrar nova ideia'),
      content: Form(
        key: _formKey,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextFormField(
                controller: _titulo,
                decoration: const InputDecoration(
                  labelText: 'Título',
                  border: OutlineInputBorder(),
                ),
                validator: (value) =>
                    value == null || value.trim().isEmpty
                        ? 'Informe o título'
                        : null,
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _descricao,
                maxLines: 3,
                decoration: const InputDecoration(
                  labelText: 'Descrição',
                  border: OutlineInputBorder(),
                ),
                validator: (value) =>
                    value == null || value.trim().isEmpty
                        ? 'Informe a descrição'
                        : null,
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _autor,
                decoration: const InputDecoration(
                  labelText: 'Nome do autor',
                  border: OutlineInputBorder(),
                ),
                validator: (value) =>
                    value == null || value.trim().isEmpty
                        ? 'Informe o autor'
                        : null,
              ),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: salvando ? null : () => Navigator.pop(context),
          child: const Text('Cancelar'),
        ),
        FilledButton(
          onPressed: salvando ? null : salvar,
          child: salvando
              ? const SizedBox(
                  width: 18,
                  height: 18,
                  child: CircularProgressIndicator(strokeWidth: 2),
                )
              : const Text('Salvar'),
        ),
      ],
    );
  }
}
