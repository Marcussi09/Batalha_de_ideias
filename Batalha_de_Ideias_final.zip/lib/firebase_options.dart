import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

/// Substitua os valores abaixo pelos dados do seu projeto Firebase.
/// A forma mais simples é executar:
/// flutterfire configure
///
/// Isso gera automaticamente este arquivo com as configurações corretas.
class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      return const FirebaseOptions(
        apiKey: 'COLOQUE_SUA_API_KEY',
        appId: 'COLOQUE_SEU_APP_ID',
        messagingSenderId: 'COLOQUE_SEU_MESSAGING_SENDER_ID',
        projectId: 'COLOQUE_SEU_PROJECT_ID',
        authDomain: 'COLOQUE_SEU_PROJECT_ID.firebaseapp.com',
        storageBucket: 'COLOQUE_SEU_PROJECT_ID.firebasestorage.app',
      );
    }

    return const FirebaseOptions(
      apiKey: 'COLOQUE_SUA_API_KEY',
      appId: 'COLOQUE_SEU_APP_ID',
      messagingSenderId: 'COLOQUE_SEU_MESSAGING_SENDER_ID',
      projectId: 'COLOQUE_SEU_PROJECT_ID',
      storageBucket: 'COLOQUE_SEU_PROJECT_ID.firebasestorage.app',
    );
  }
}
