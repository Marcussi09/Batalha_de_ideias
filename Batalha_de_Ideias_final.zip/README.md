# Batalha de Ideias

Projeto Flutter da atividade "Batalha de Ideias", utilizando Cloud Firestore.

## Funcionalidades

- Cadastrar ideia com título, descrição e autor.
- Salvar as ideias na coleção `ideias`.
- Iniciar cada ideia com `votos: 0`.
- Mostrar todas as ideias cadastradas em tempo real.
- Votar em uma ideia, aumentando os votos em 1.
- Excluir uma ideia do Firestore.
- Mostrar a ideia mais votada.
- Compartilhar os dados entre os usuários conectados ao mesmo Firebase.

## Configuração do Firebase

1. Crie um projeto no Firebase.
2. Ative o Cloud Firestore.
3. No terminal, dentro da pasta do projeto, instale/execute o FlutterFire CLI:

   `dart pub global activate flutterfire_cli`

4. Depois execute:

   `flutterfire configure`

5. Selecione o projeto Firebase criado e a plataforma desejada.
6. O comando irá substituir/gerar o arquivo `lib/firebase_options.dart`.
7. Configure as regras do Firestore usando o conteúdo de `firestore.rules`.

## Executar

```bash
flutter pub get
flutter run
```

Para testar o compartilhamento, abra o aplicativo em dois navegadores/dispositivos conectados ao mesmo projeto Firebase.
